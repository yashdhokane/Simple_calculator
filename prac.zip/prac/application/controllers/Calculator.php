<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calculator extends CI_Controller {

    public function index() {
        $this->load->view('calculator_view');
    }

    public function calculate() {
        $num1 = $this->input->post('num1');
        $num2 = $this->input->post('num2');
        $operator = $this->input->post('operator');

        $result = 0;

        switch ($operator) {
            case 'add':
                $result = $num1 + $num2;
                break;
            case 'subtract':
                $result = $num1 - $num2;
                break;
            case 'multiply':
                $result = $num1 * $num2;
                break;
            case 'divide':
                if ($num2 != 0) {
                    $result = $num1 / $num2;
                } else {
                    $result = 'Cannot divide by zero';
                }
                break;
        }

        $data['result'] = $result;
        $this->load->view('calculator_view', $data);
    }
}
