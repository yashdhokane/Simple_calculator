<!DOCTYPE html>
<html>
<head>
    <title>Result</title>
</head>
<body>
    <h2>Addition Result</h2>
    <p><?php echo $num1; ?> + <?php echo $num2; ?> = <?php echo $sum; ?></p>
    
</body>
</html>
