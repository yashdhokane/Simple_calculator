<!DOCTYPE html>
<html>
<head>
    <title>Calculator</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }

        .calculator-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        .result {
            margin-top: 15px;
            font-size: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="calculator-container">
        <h2 class="text-center mb-4">Simple Calculator</h2>
        
        <form action="<?php echo site_url('calculator/calculate'); ?>" method="post">
            <div class="form-group">
                <input type="number" class="form-control" name="num1" placeholder="Number 1" required>
            </div>
            <div class="form-group">
                <input type="number" class="form-control" name="num2" placeholder="Number 2" required>
            </div>
            <div class="form-group">
                <select class="form-control" name="operator" required>
                    <option value="add">Add</option>
                    <option value="subtract">Subtract</option>
                    <option value="multiply">Multiply</option>
                    <option value="divide">Divide</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block">Calculate</button>
            </div>
        </form>

        <?php if(isset($result)): ?>
            <div class="result">
                Result: <?php echo $result; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Include Bootstrap JS (Optional) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
